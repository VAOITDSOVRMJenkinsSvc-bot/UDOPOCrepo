var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./VASSCopyButton/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./VASSCopyButton/index.ts":
/*!*********************************!*\
  !*** ./VASSCopyButton/index.ts ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.ClipboardTextbox = void 0;\n\nvar ClipboardTextbox =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function ClipboardTextbox() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  ClipboardTextbox.prototype.init = function (context, notifyOutputChanged, state, container) {\n    try {\n      // Add control initialization code\n      this._context = context; //this._container=container;\n\n      this._container = document.createElement(\"div\");\n      this._container.className = \"DivContainerStyle\"; //Create table Layout\n\n      this._tableLayout = document.createElement(\"table\");\n      this._tableLayout.className = \"TableLayout\";\n\n      var row = this._tableLayout.insertRow();\n\n      row.tabIndex = -1;\n      this._tableLayout.tabIndex = -1; //Cell where the texbox resides\n\n      var textCell = row.insertCell();\n      textCell.tabIndex = -1;\n      textCell.className = \"TextCell\"; //Cell where the copy button resides\t\t\n\n      var copyButtonCell = row.insertCell();\n      copyButtonCell.className = \"ButtonCell\";\n      copyButtonCell.tabIndex = -1; //Defne event handlers\n\n      this._notifyOutputChanged = notifyOutputChanged;\n      this._refreshData = this.refreshData.bind(this);\n      this._buttonClick = this.buttonClick.bind(this);\n      this._keyDownDivButton = this.divButtonKeyDown.bind(this); //Create Textbox\n\n      this.inputElement = document.createElement(\"input\");\n      this.inputElement.tabIndex = 0;\n      this.inputElement.setAttribute(\"id\", \"mcs_textboxClipboard\");\n      this.inputElement.className = \"TextboxContainerStyle\";\n      this.inputElement.setAttribute(\"type\", \"text\");\n      this.inputElement.addEventListener(\"input\", this._refreshData);\n      var txtAriaLabel = this._context.parameters.TextboxAriaLabel.raw;\n      this.inputElement.setAttribute(\"aria-label\", txtAriaLabel); //Create the copy button\n\n      this.buttonElement = document.createElement(\"div\");\n      this.buttonElement.className = \"DivButton\"; //this.buttonElement.setAttribute(\"alt\", \"Click/Hit Enter to copy the phone number.\");\n\n      this.buttonElement.setAttribute(\"role\", \"button\");\n      var btnAriaLabel = this._context.parameters.ButtonAriaLabel.raw;\n      this.buttonElement.setAttribute(\"aria-label\", btnAriaLabel); //this.buttonElement.innerHTML=\"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'><path class='icon-asx-grey' d='M10.707 3h-1l-3-3H1v13h4v3h10V7.293L10.707 3zM11 4.707L13.293 7H11V4.707zM2 12V1h4.293l2 2H5v9H2zm4 3V4h4v4h4v7H6z'/></svg>\"\n\n      var svgElement = document.createElementNS(\"http://www.w3.org/2000/svg\", \"svg\");\n      svgElement.setAttribute(\"viewBox\", \"0 0 16 16\");\n      var svgPath = document.createElementNS(\"http://www.w3.org/2000/svg\", \"path\");\n      svgPath.setAttribute(\"class\", \"icon-asx-grey\");\n      svgPath.setAttribute(\"d\", \"M10.707 3h-1l-3-3H1v13h4v3h10V7.293L10.707 3zM11 4.707L13.293 7H11V4.707zM2 12V1h4.293l2 2H5v9H2zm4 3V4h4v4h4v7H6z\");\n      svgElement.appendChild(svgPath);\n      this.buttonElement.appendChild(svgElement);\n      this.buttonElement.addEventListener(\"click\", this._buttonClick);\n      this.buttonElement.addEventListener(\"keypress\", this._keyDownDivButton);\n      this.buttonElement.tabIndex = 0; //Create copy control\n\n      this.textArea = document.createElement(\"textarea\");\n      this.textArea.setAttribute(\"readonly\", \"\");\n      this.textArea.style.position = \"absolute\";\n      this.textArea.style.left = '-9999px';\n      this.textArea.tabIndex = -1; //this.textArea.hidden=true;\t\t\n\n      textCell.appendChild(this.inputElement);\n      copyButtonCell.appendChild(this.buttonElement);\n\n      this._container.appendChild(this._tableLayout);\n\n      this._container.appendChild(this.textArea);\n\n      this._value = context.parameters.Attribute.raw;\n      container.appendChild(this._container); //somecomment\n\n      this.inputElement.value = this._value;\n    } catch (ex) {\n      console.log(ex.message);\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  ClipboardTextbox.prototype.updateView = function (context) {\n    try {\n      // Add code to update control view\n      this._value = context.parameters.Attribute.raw;\n      this._context = context;\n      this.inputElement.value = this._value;\n    } catch (ex) {\n      console.log(ex.message);\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  ClipboardTextbox.prototype.getOutputs = function () {\n    return {\n      Attribute: this._value\n    };\n  };\n\n  ClipboardTextbox.prototype.refreshData = function (evt) {\n    try {\n      this._value = this.inputElement.value; //this.inputElement.value = this.inputElement.value;\n\n      this._notifyOutputChanged();\n    } catch (ex) {\n      console.log(ex.message);\n    }\n  };\n\n  ClipboardTextbox.prototype.divButtonKeyDown = function (evt) {\n    try {\n      var kEvent = evt;\n\n      if (kEvent != null && kEvent.charCode === 13) {\n        this.CopyText();\n      }\n    } catch (ex) {\n      console.log(ex.message);\n    } //}\n\n  };\n\n  ClipboardTextbox.prototype.CopyText = function () {\n    var _a;\n\n    try {\n      var re = new RegExp(this._context.parameters.RegularExpresion.raw, \"g\");\n\n      var formattedValue = this._value.replace(re, (_a = this._context.parameters.ReplaceWith.raw) !== null && _a !== void 0 ? _a : \"\"); //alert(\"Formatted Value:\" + formattedValue);\n\n\n      this.textArea.value = formattedValue;\n      this.textArea.select();\n      document.execCommand('copy');\n    } catch (ex) {\n      console.log(ex.message);\n    }\n  };\n\n  ClipboardTextbox.prototype.buttonClick = function (evt) {\n    this.CopyText();\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  ClipboardTextbox.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n    this.inputElement.removeEventListener(\"input\", this._refreshData);\n    this.buttonElement.removeEventListener(\"click\", this._buttonClick);\n    this.buttonElement.removeEventListener(\"keypress\", this._buttonClick);\n  };\n\n  return ClipboardTextbox;\n}();\n\nexports.ClipboardTextbox = ClipboardTextbox;\n;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./VASSCopyButton/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Mcs.Controls.ClipboardTextbox', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ClipboardTextbox);
} else {
	var Mcs = Mcs || {};
	Mcs.Controls = Mcs.Controls || {};
	Mcs.Controls.ClipboardTextbox = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ClipboardTextbox;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}